目前卡在json数据问题
已查至客户端网络管理器的login方法，调用了sendcommand方法，然后登录接收到的json是这样的login_resp {"code":0,"data":{"email":"","nickname":"1","username":"1"},"message":"登录成功"}
接下来是去掉前缀{"code":0,"data":{"email":"","nickname":"1","username":"1"},"message":"登录成功"}
大概发现问题了，一个可能是去掉前缀后interface解析失败
另外一个存在的问题是login rsp根本没有那些键，登录回调的解析肯定会出问题
code data{email nick user} message 这是发过来的Json结果
这是期望的解析结构 xx {data{user_info{user_id}}}
9.24晚
解决了，但是现在还有别的json问题


服务大厅
传入userid 为 1.00000000000e   原因：go强类型，默认解析float64 1.0 传入出问题，需要手动转为int
妈的，卡在服务大厅没有卡片了，可能是json直接解析给结构体的问题，啥比gemini一直重复回答