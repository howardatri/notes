坑超级多
首先下好mysql(8.3)，然后解压目录，然后自己创建my.ini
内容详见github

#注意 
1这里ini设置了默认字符集，后面(调用mysql存储过程的问题)
2在新建查询过程的时候 需要修改
3新建自己数据库的时候，记得把字符集填上f8mb4]，排序规则填上utf8mb4


下辰哥网盘的，然后整navicat参考
https://www.cnblogs.com/wasline/p/18023683

在新建查询过程的时候可以将 -- email也不存在，更新user_id表 [![](https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png)UPDATE](https://search.bilibili.com/all?from_source=webcommentline_search&keyword=UPDATE&seid=3668196233998129951&from_avid=1753287776&from_comid=258319779568) `user_id` SET `id` = `id` + 1; 更改为： -- 检查 user_id 表是否为空 IF (SELECT COUNT(*) FROM `user_id`) = 0 THEN     -- 如果 user_id 表为空，初始化 id 为 1     INSERT INTO `user_id` (id) VALUES (1); ELSE     -- email也不存在，更新user_id表     UPDATE `user_id` SET `id` = `id` + 1; END IF; 这样的话，空表也可以直接插入了，大家插入出现-1错误的时候，可以去数据库单独执行一下存储过程，如果还是-1，那么就是存储过程有问题，不要盯着vs代码啦。对了，如果数据库明明有%权限的root用户还是提示没有，可以刷新一下数据库权限，具体代码去问问ai就好。

#注意docker 我跳过docker了
配置sqlconnector

添加mysqldao类
先封装sql连接和sql池(加入上次时间 检测)

然后是mysqlpool:
1有一线程用于检测(每隔一分钟检测没有操作) ->心跳机制
2scehma数据库名字

check里更新 取出
#defer:  #RAII go思想
使用 `Defer` 对象确保连接在函数结束时被放回连接池
声明在上面，但是能保证函数}执行之前释放

```
			Defer defer([this, &con]() {
				pool_.push(std::move(con));
				});
```

```
//Defer类
class Defer {
public:
	//接受一个lambda表达式或函数指针
	Defer(std::function<void()> func):func_(func){}

	//析构函数执行传入的函数
	~Defer() {
		func_();
	}
private:
    std::function<void()> func_;
};

```


先获取队列容量
如果当前时间戳-上次操作时间>5s
```
std::unique_ptr<sql::Statement>stmt(con>_con>createStatement());
		stmt->executeQuery("SELECT 1");
		con->_last_oper_time = timestamp;
```

这一套公式池子  加锁
get与return:
get:条件变量等待，一个是关闭标志一个是非空 然后出来判断关闭 pop
return:如果关闭标志直接返回 否则推然后Notifyone
然后就是close和析构

接下来写用户信息结构体

和mysqldao类:进行增删改查
构造函数读取config配置 reset池子
接下来先实现reguser函数功能


写一个reg_user存储过程
存储过程？有修改
```
在新建查询过程的时候可以将 -- email也不存在，更新user_id表 
`user_id` SET `id` = `id` + 1; 更改为： -- 检查 user_id 表是否为空 IF (SELECT COUNT(*) FROM `user_id`) = 0 THEN     -- 如果 user_id 表为空，初始化 id 为 1     INSERT INTO `user_id` (id) VALUES (1); ELSE     -- email也不存在，更新user_id表     UPDATE `user_id` SET `id` = `id` + 1; END IF; 这样的话，空表也可以直接插入了
```

mysql相关
### **什么是定义者（Definer）**

在 MySQL 中，某些数据库对象（如视图、存储过程、触发器等）可以有一个“定义者”（definer）。定义者是指创建这些对象时使用的用户身份。当这些对象被调用或执行时，它们会以定义者的权限运行，而不是调用者的权限。定义者的作用是确保这些对象在执行时有足够的权限。

例如，如果你创建了一个视图，它的定义者可能是创建该视图时的用户（如 `root`）。如果定义者被设置为 `'root'@'%'`，那么 MySQL 会期望有一个能够从任何主机连接的 `root` 用户。

#术语 
在软件开发中，尤其是在分层架构（如 MVC 或分层架构模式）中，**DAO** 是一个常见的术语，它代表 **Data Access Object（数据访问对象）**。DAO 的主要职责是封装对数据库或其他数据存储层的访问逻辑，为上层（如服务层或控制器层）提供数据操作的接口。

spring框架使用controller, service, dao
### **1. DAO 的作用**

DAO 的主要作用是将数据访问逻辑与业务逻辑分离，从而实现以下目标：

- **解耦**：将数据访问代码从业务逻辑代码中分离出来，使得代码更加模块化，便于维护和扩展。
    
- **重用**：提供通用的数据访问方法，可以在多个地方复用。
    
- **简化**：为上层提供一个简单的接口，隐藏底层数据库操作的复杂性



## 数据库管理者

我们需要建立一个数据库管理者用来实现服务层，对接逻辑层的调用
内涵成员DAO
## 逻辑层调用

在逻辑层注册消息处理。




链接错误:dll仍然要设置Lib