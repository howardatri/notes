
## ChatServer

一个TCP服务器必然会有连接的接收，维持，收发数据等逻辑。那我们就要基于asio完成这个服务的搭建。主服务是这个样子的

信号复习
template <typename... SignalNumbers>
signal_set(boost::asio::io_context& io_context,
           SignalNumbers... signal_numbers);

先看一遍吧


ioservices这个vector什么时候构造？在构造函数给定容量初始化的时候

```
_works[i] = std::unique_ptr<Work>(new Work(_ioServices[i]));
```
| 动作                           | 含义                                    |
| ---------------------------- | ------------------------------------- |
| `new Work(_ioServices[i])`   | 创建一个 **work 实例并绑定到第 i 个 io\_context** |
| `std::unique_ptr<Work>(...)` | 把裸指针包成 `unique_ptr`                   |
| `_works[i] = ...`            | 把独占指针放进 `_works[i]`                   |

```
for (std::size_t i = 0; i < _ioServices.size(); ++i) {
    _threads.emplace_back([this, i]() {
        _ioServices[i].run();   // 事件循环
    });
}
```
| 元素                     | 作用                                         |
| ---------------------- | ------------------------------------------ |
| `_threads`             | `std::vector<std::thread>`，用来保存工作线程        |
| `emplace_back(...)`    | 就地创建线程，避免拷贝                                |
| `[this, i]`            | lambda 捕获：需要访问成员变量 `_ioServices` 和当前索引 `i` |
| `_ioServices[i].run()` | **阻塞式事件循环**，不断分发异步任务（读/写/定时器等）             |
服务停了还需要线程join
cserver
acceptor asio要求我们这么写

流程
![[Pasted image 20250724173905.png]]

accept调用成员函数需要把自身传过去

tcp与http原理
![[Pasted image 20250724175411.png]]

csession
先读取头部