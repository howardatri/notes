
![[Pasted image 20250518124859.png]]
为什么用new而不是make_shared?
make_shared需要访问类的构造函数，但是这个单例类的构造函数是protected的，无法被智能指针访问

static成员一定要初始化

然后就是有点绕的析构
为了让基类访问子类的私有，所以把基类声明友元

singleton里面getInstance里面有个new T需要构造，T是httpmgr，所以声明友元


在 Qt 中，`private slots:` 是一个特殊的声明，用于定义类的私有槽（slot）。槽是 Qt 信号与槽机制的一部分，用于响应信号（signal）的发射。通过将槽声明为 `private`，这些槽只能在类的内部被调用，通常用于封装类的内部逻辑
cpp里包含头文件，防止互引用

### 2. **`QObject::connect()` 方法**

`QObject::connect()` 是 Qt 的信号与槽机制的核心函数，用于将一个信号连接到一个槽函数。当信号被触发时，槽函数会被自动调用。


### 生成原因

在 Qt 中，如果你在类的声明中使用了 `Q_OBJECT` 宏，那么 moc 会自动解析该类的头文件，并生成一个以 `moc_` 开头的 `.cpp` 文件。例如，如果你有一个名为 `HttpMgr` 的类，并且在它的头文件中使用了 `Q_OBJECT` 宏，那么 moc 会生成一个名为 `moc_httpmgr.cpp` 的文件。