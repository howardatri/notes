我们添加一个新的类，名字叫CServer。添加成功后生成的CServer.h和CServer.cpp也会自动加入到项目中。

CServer类构造函数接受一个端口号，创建acceptor接受新到来的链接。
CServer.h中声明acceptor, 以及用于事件循环的上下文iocontext,和构造函数
***注意***  
Start函数内创建HttpConnection类型智能指针，将_socket内部数据转移给HttpConnection管理，_socket继续用来接受写的链接。

socket没有拷贝构造，也不能&(会出问题),一般用move
`httpconnection(std::move)`
但是也不直接move，而是用智能指针
`std::make_shared<httpcon>(std::move(socket))->start();`


我们创建const.h将文件件和一些作用于声明放在const.h里，这样以后创建的文件包含这个const.h即可，不用写那么多头文件了。
新建HttpConnection类文件，在头文件添加声明
==HttpConnection 是一个专门用于处理单个 HTTP 客户端连接的类。它负责从客户端读取 HTTP 请求、处理请求并生成响应，同时管理连接的生命周期和超时。==
`_buffer 用来接受数据`
`_request 用来解析请求`
`_response 用来回应客户端`
#注意 java等里面有超时封装，cpp只能我们自己写
`_deadline 用来做定时器判断请求是否超时`

stedy_timer底层事件轮询

我们考虑在HttpConnection::Start内部调用http::async_read函数，其源码为

```
async_read(
    AsyncReadStream& stream,
    DynamicBuffer& buffer,
    basic_parser<isRequest>& parser,
    ReadHandler&& handler)
```

第一个参数为异步可读的数据流，大家可以理解为socket.

第二个参数为一个buffer，用来存储接受的数据，因为http可接受文本，图像，音频等多种资源文件，所以是Dynamic动态类型的buffer。

第三个参数是请求参数，我们一般也要传递能接受多种资源类型的请求参数。

第四个参数为回调函数，接受成功或者失败，都会触发回调函数，我们用lambda表达式就可以了。

有时候trycatch好一点，有时候引发更深层次问题

error_code为什么可以当作判断？
重载了==运算符，返回一个bool值

http服务器不需要粘包处理

我们实现HandleReq
```
void HttpConnection::HandleReq() {
    //设置版本
    _response.version(_request.version());
    //设置为短链接
    _response.keep_alive(false);

    if (_request.method() == http::verb::get) {
        bool success = LogicSystem::GetInstance()->HandleGet(_request.target(), shared_from_this());
        if (!success) {
            _response.result(http::status::not_found);
            _response.set(http::field::content_type, "text/plain");
            beast::ostream(_response.body()) << "url not found\r\n";
            WriteResponse();
            return;
        }

        _response.result(http::status::ok);
        _response.set(http::field::server, "GateServer");
        WriteResponse();
        return;
    }
}
```
这样我们在HttpConnection里实现WriteResponse函数
```
void HttpConnection::WriteResponse() {
    auto self = shared_from_this();
    _response.content_length(_response.body().size());
    http::async_write(
        _socket,
        _response,
        [self](beast::error_code ec, std::size_t)
        {
            self->_socket.shutdown(tcp::socket::shutdown_send, ec);
            self->deadline_.cancel();
        });
}
```

因为http是短链接，所以发送完数据后不需要再监听对方链接，直接断开发送端即可。

另外，http处理请求需要有一个时间约束，发送的数据包不能超时。所以在发送时我们启动一个定时器，收到发送的回调后取消定时器。
我们实现检测超时的函数:
定时器长时间检测，对端一直没有触发回调(writeresponse)，
超时socket强制断客户端

我们先实现LogicSystem，采用单例模式，单例基类之前讲解过了
`_post_handlers和_get_handlers分别是post请求和get请求的回调函数map，key为路由，value为回调函数。

我们实现RegGet函数，接受路由和回调函数作为参数
```
void LogicSystem::RegGet(std::string url, HttpHandler handler) {
    _get_handlers.insert(make_pair(url, handler));
}
```
在构造函数中实现具体的消息注册
```
LogicSystem::LogicSystem() {
    RegGet("/get_test", [](std::shared_ptr<HttpConnection> connection) {
        beast::ostream(connection->_response.body()) << "receive get_test req";
    });
}
```
在你的代码中，`/get_test` 是一个 HTTP 请求的路径（URL），它被注册为一个处理 GET 请求的路由。当 HTTP 服务器接收到一个目标路径为 `/get_test` 的 GET 请求时，`LogicSystem` 会调用与该路径关联的处理函数（`HttpHandler`），来处理这个请求并生成响应。

为防止互相引用，以及LogicSystem能够成功访问HttpConnection，在LogicSystem.cpp中包含HttpConnection头文件
并且在HttpConnection中添加友元类LogicSystem, 且在HttpConnection.cpp中包含LogicSystem.h文件
```
bool LogicSystem::HandleGet(std::string path, std::shared_ptr<HttpConnection> con) {
    if (_get_handlers.find(path) == _get_handlers.end()) {
        return false;
    }
    _get_handlers[path](con);
    return true;
}
```
然后实现writeresponse,checkddl

#debug 构造httpconnection时传socket是引用，爆了个解决不了的错

这段代码的作用是：
```
		unsigned short port = static_cast<unsigned short>(8080);
		net::io_context ioc{ 1 };
		boost::asio::signal_set signals(ioc, SIGINT, SIGTERM);
		signals.async_wait([&ioc](const boost::system::error_code& error, int signal_number) {
			if (error) {
				return;
			}
			ioc.stop();
			});
```
1. 定义服务器监听的端口号。
2. 初始化一个 `io_context` 对象，用于管理 I/O 服务。
3. 注册对 `SIGINT` 和 `SIGTERM` 信号的监听。
4. 在接收到这些信号时，停止 `io_context` 的事件循环，从而优雅地关闭程序。


启动server后需要ioc.run开始轮询

流程：server启动后，监听链接 交给connectioN管理 con监听读事件，处理读的请求handlereq
调用logic处理请求 调用handleget 传url 智能指针  gethandler通过url在map找,找不到404,找到了就是键值对map返回一个回调函数(在构造logic时注册)
`_get_handlers[path](con);`这句是按path找到传回对应回调，传参con
，处理分成功失败


写：规定时间写完就取消定时器，否则超时强制关闭

tcp读完继续监听，但是http只负责接受后回包(短链接)