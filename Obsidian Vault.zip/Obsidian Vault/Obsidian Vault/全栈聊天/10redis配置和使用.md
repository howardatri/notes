## 设置验证码过期(12期)

我们的验证码是要设置过期的，可以用redis管理过期的验证码自动删除，key为邮箱，value为验证码，过期时间为3min。

修改redis.windows.conf, 并且修改端口

```
port 6380
```

找到requirepass foobared，下面添加requirepass

```
# requirepass foobared
requirepass 123456
```

启动redis 服务器 `.\redis-server.exe .\redis.windows.conf`
启动客户端 `.\redis-cli.exe -p 6380`, 输入密码登录成功

## 编译
Linux的redis库直接编译安装即可，windows反而麻烦一些，我们先阐述windows环境如何配置redis库， C++ 的redis库有很多种，最常用的有hredis和redis-plus-plus. 我们用hredis源码编译训练 .   这里介绍一种简单的安装方式---vcpkg

只需要生成hiredis工程和Win32_Interop工程即可，分别点击生成,生成hiredis.lib和Win32_Interop.lib即可

右键两个工程的属性，代码生成里选择运行时库加载模式为MDD(Debug模式动态运行加载)，为了兼容我们其他的库，其他的库也是MDD模式
## 代码测试

我们需要写代码测试库配置的情况




## redis库debug
在主函数中调用TestRedis，编译项目时发现编译失败，提示

![](https://cdn.llfc.club/1710812579501.jpg?x-oss-process=image%2Fwatermark%2Ctype_d3F5LW1pY3JvaGVp%2Csize_19%2Ctext_5oGL5oGL6aOO6L6wemFjaw%3D%3D%2Ccolor_FFFFFF%2Cshadow_50%2Ct_80%2Cg_se%2Cx_10%2Cy_10 "null")

在同时使用Redis连接和socket连接时，遇到了Win32_Interop.lib和WS2_32.lib冲突的问题, 因为我们底层用了socket作为网络通信，也用redis，导致两个库冲突。

引起原因主要是Redis库Win32_FDAPI.cpp有重新定义了socket的一些方法引起来冲突

去掉Redis库里面的socket的函数的重定义，把所有使用这些方法的地方都改为下面对应的函数

考虑大家修改起来很麻烦，可以下载我的代码

[https://gitee.com/secondtonone1/windows-redis](https://gitee.com/secondtonone1/windows-redis)

再次编译生成hredis和Win32_Interop的lib库，重新配置下，项目再次编译就通过了。


redis里传字符串
字符串要用cstr