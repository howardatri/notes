# visual studio配置protobuf

## protobuf简介  
Protocol Buffers（简称 Protobuf）是一种轻便高效的序列化数据结构的协议，由 Google 开发。它可以用于将结构化数据序列化到二进制格式，并广泛用于数据存储、通信协议、配置文件等领域。 我们的逻辑是有类等抽象数据构成的，而tcp是面向字节流的，我们需要将类结构序列化为字符串来传输。
压缩成二进制                  主要是支持grpc      分布式设计
公司多用json

## visual stuido配置protobuf

我们新建一个控制台项目，在项目属性中，配置选择Debug，平台选择X64，选择VC++目录，  
在包含目录中添加 D:\cppsoft\protoc\include  
在库目录中添加 D:\cppsoft\protoc\bin

在链接器的输入选项中添加protobuf用到的lib库

```
libprotobufd.lib
libprotocd.lib
```

到此，visual studio 的protobuf配置完毕。

这个文件定义了一个名为Book的消息类型，包含三个字段：name、pages和price。其中每个字段都有一个数字标识符，用于标识该字段在二进制流中的位置。  
我们使用protoc.exe 基于msg.proto生成我们要用的C++类  
在proto所在文件夹执行如下命令

```
protoc --cpp_out=. ./msg.proto
```

--cpp_out= 表示指定要生成的pb文件所在的位置  
./msg.proto 表示msg.proto所在的位置，因为我们是在msg.proto所在文件夹中执行的protoc命令,所以是当前路径即可。  
执行后，会看到当前目录生成了msg.pb.h和msg.pb.cc两个文件，这两个文件就是我们要用到的头文件和cpp文件。  
我们将这两个文件添加到项目里，然后在主函数中包含msg.pb.h，做如下测试


#回顾 运用int length = read(sock,buffer(msg,len));这个读，看似是赋值给length，其实同时把对端发送的msg读取到本地的msg中了，所以这个操作实际上存储了msg的实际内容。

async_read_some可以简化为read，一次读完(包括粘包)
这样就需要两个回调函数，新增一个包头的处理