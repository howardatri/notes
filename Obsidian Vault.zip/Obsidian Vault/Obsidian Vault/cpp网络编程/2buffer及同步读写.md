## 关于buffer

任何网络库都有提供buffer的数据结构，所谓buffer就是接收和发送数据时缓存数据的结构。  
boost::asio提供了asio::mutable_buffer 和 asio::const_buffer这两个结构，他们是一段连续的空间，首字节存储了后续数据的长度。  
asio::mutable_buffer用于写服务，asio::const_buffer用于读服务。但是这两个结构都没有被asio的api直接使用。  
对于api的buffer参数，asio提出了MutableBufferSequence和ConstBufferSequence概念，他们是由多个asio::mutable_buffer和asio::const_buffer组成的。也就是说boost::asio为了节省空间，将一部分连续的空间组合起来，作为参数交给api使用。  
我们可以理解为MutableBufferSequence的数据结构为std::vector[asio::mutable_buffer](asio::mutable_buffer)
每隔vector存储的都是mutable_buffer的地址，每个mutable_buffer的第一个字节表示数据的长度，后面跟着数据内容。  
这么复杂的结构交给用户使用并不合适，所以asio提出了buffer()函数，该函数接收多种形式的字节流，该函数返回asio::mutable_buffers_1 o或者asio::const_buffers_1结构的对象。  
如果传递给buffer()的参数是一个只读类型，则函数返回asio::const_buffers_1 类型对象。  
如果传递给buffer()的参数是一个可写类型，则返回asio::mutable_buffers_1 类型对象。  
asio::const_buffers_1和asio::mutable_buffers_1是asio::mutable_buffer和asio::const_buffer的适配器，提供了符合MutableBufferSequence和ConstBufferSequence概念的接口，所以他们可以作为boost::asio的api函数的参数使用。  
**简单概括一下，我们可以用buffer()函数生成我们要用的缓存存储数据。**
**`asio::const_buffers_1` 和 `asio::mutable_buffers_1` 的具体作用**
- **`asio::const_buffers_1`**
    - 包装一个只读的内存缓冲区。
    - 通常用于读操作，如从网络接收数据到一个只读缓冲区。
    - 实现了 **ConstBufferSequence** 概念。

比如boost的发送接口send要求的参数为ConstBufferSequence类型
我们需要将"Hello Word转化为该类型"
```
void use_const_buffer() {
    std::string buf = "hello world!";
    asio::const_buffer  asio_buf(buf.c_str(), buf.length());
    std::vector<asio::const_buffer> buffers_sequence;
    buffers_sequence.push_back(asio_buf);
}
```
最终buffers_sequence就是可以传递给发送接口send的类型。但是这太复杂了，可以直接用buffer函数转化为send需要的参数类型
```
void use_buffer_str() {
    asio::const_buffers_1 output_buf = asio::buffer("hello world");
}
```
output_buf可以直接传递给该send接口。我们也可以将数组转化为send接受的类型
```
void use_buffer_array(){
    const size_t  BUF_SIZE_BYTES = 20;
    std::unique_ptr<char[] > buf(new char[BUF_SIZE_BYTES]);
    auto input_buf = asio::buffer(static_cast<void*>(buf.get()), BUF_SIZE_BYTES);
}
```
**buffer_1就是可以直接交给send等的数据接口**

# 同步读写

### 同步写write_some
 同步其实没必要
boost::asio提供了几种同步写的api，write_some可以每次向指定的空间写入固定的字节数，如果写缓冲区满了，就只写一部分，返回写入的字节数。
//循环发送
//write_some 返回每次写入的字节数
```

	while (total_bytes_written != buf.length()) {
		total_bytes_written += sock.write_some(asio::buffer(buf.c_str() + total_bytes_written,
			buf.length() - total_bytes_written));
	}
```

//回顾 端点 上下文 socket(ip,端口号)，链接

用户态发送字节数，tcp不一定能全发出去->write_some

如何实现 直接发完目标字节数？
## 同步写send()
write_some使用起来比较麻烦，需要多次调用，asio提供了send函数。send函数会一次性将buffer中的内容发送给对端，如果有部分字节因为发送缓冲区满无法发送，则阻塞等待，直到发送缓冲区可用，则继续发送完成。

```
int send_length =sock.send(asio::buffer(buf.c_str(), buf.length()));
```
send三种:1<0出现系统错误 2=0对端关闭 3一定为buf长度

## 同步写write

类似send方法，asio还提供了一个write函数，可以一次性将所有数据发送给对端，如果发送缓冲区满了则阻塞，直到发送缓冲区可用，将数据发送完成。

```
int send_length  = asio::write(sock, asio::buffer(buf.c_str(), buf.length()));
```

## 同步读read_some

同步读和同步写类似，提供了读取指定字节数的接口read_some

```
    while (total_bytes_read != MESSAGE_SIZE) {
        total_bytes_read += sock.read_some(
            asio::buffer(buf + total_bytes_read,
                MESSAGE_SIZE - total_bytes_read));
    }
```

## 同步读receive

可以一次性同步接收对方发送的数据
```
receive(asio::buffer(buf.c_str(),BUFF_SIZE));
```

## 同步读read

可以一次性同步读取对方发送的数据
```
read(sock,asio::buffer(buf.c_str(),BUFF_SIZE));
```

## 读取直到指定字符(少)

我们可以一直读取，直到读取指定字符结束
read_until
```
asio::streambuf buf;
asio::read_until(sock, buf, '\n');

std::string message;
std::istream input_stream(&buf);
std::getline(input_stream, message);
return message;

```