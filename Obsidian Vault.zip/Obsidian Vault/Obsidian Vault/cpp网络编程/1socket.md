配置:右键项目-属性-vc++目录{1包含目录(至boost_1_85_)2库目录(stage\lib)}
·
基于tcp
创建endpoint    创建端点之后才可以用户连接
#零基础:extern只包含一次
不要用using namespace std;命名空间污染
## 终端节点的创建

所谓终端节点就是用来通信的端对端的节点，可以通过ip地址和端口构造，其的节点可以连接这个终端节点做通信.  
如果我们是客户端，我们可以通过对端的ip和端口构造一个endpoint，用这个endpoint和其通信。

如果是服务端，则只需根据本地地址绑定就可以生成endpoint
v4/v6 any()

## 创建socket

创建socket分为4步，创建上下文iocontext，选择协议，生成socket，打开socket。
现在优化了，创建socket不用打开判断error_code

==实际上就一句话，只需要一个上下文参数==

上述socket只是通信的socket，如果是服务端，我们还需要生成一个acceptor的socket，用来接收新的连接。

现在也优化了，一步直接好
asio::ip::tcp::acceptor a(ios, asio::ip::tcp::v4(), 3333);

## 创建acceptor
==参数:上下文ioc,端点endpoint(可当场构造 )==
上述socket只是通信的socket，如果是服务端，我们还需要生成一个acceptor的socket，用来接收新的连接。
```
int  create_acceptor_socket() {
    asio::io_context ios;
    asio::ip::tcp protocol = asio::ip::tcp::v6();


    asio::ip::tcp::acceptor acceptor(ios);


    boost::system::error_code ec;

    if (ec.value() != 0) {
        // Failed to open the socket.
        std::cout
            << "Failed to open the acceptor socket!"
            << "Error code = "
            << ec.value() << ". Message: " << ec.message();
        return ec.value();
    }

    return 0;
}
```
## 绑定acceptor

对于acceptor类型的socket，服务器要将其绑定到指定的断点,所有连接这个端点的连接都可以被接收到。
	acceptor.bind(ep);
	==参数没有就要绑定ep==
## 服务器接收连接

当有客户端连接时，服务器需要接收连接
```
int accept_new_connection() {
	const int BACKLOG_SIZE = 30;
	unsigned short port_num = 3333;
	asio::ip::tcp::endpoint ep(asio::ip::address_v4::any(), port_num);
	asio::io_context ios;
	try {
		asio::ip::tcp::acceptor acceptor(ios, ep.protocol());
		acceptor.bind(ep);
		acceptor.listen(BACKLOG_SIZE);
		asio::ip::tcp::socket sock(ios);
		acceptor.accept(sock);

	}
	catch (system::system_error& e) {
		std::cout << "failed to create acceptor.error code=" << e.code().value() << "message is " << e.what() << std::endl;
		return e.code().value();
	}
}
```

## 连接指定的端点

作为客户端可以连接服务器指定的端点进行连接
客户链接，服务器绑定

总结
服务器生成端点，acceptor(socket),绑定端点,监听，accept返回新连接交给socket
客户端怎么链接？
链接服务器地址，转成asio地址格式和提供端口号->生成端点(服务器对端)，
创建socket(服务(io_context上下文)，协议(对端支持的协议))