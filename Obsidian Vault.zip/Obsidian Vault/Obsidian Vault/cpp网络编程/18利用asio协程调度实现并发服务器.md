## 简介

之前介绍了asio服务器并发编程的几种模型，包括单线程，多线程IOServicePool，多线程IOThreadPool等，今天带着大家利用asio协程实现并发服务器。利用协程实现并发程序有两个好处  
1   将回调函数改写为顺序调用，提高开发效率。  
2   协程调度比线程调度更轻量化，因为协程是运行在用户空间的，线程切换需要在用户空间和内核空间切换。

## 协程案例

asio官网提供了一个协程并发编程的案例，我们列举一下

coroutine是对称性协程，协程挂起 后可以任意恢复

1   我们用awaitable声明了一个函数，那么这个函数就变为可等待的函数了，比如`listener`被添加`awaitable<void>`之后，就可以被协程调用和等待了。 2 `co_spawn`表示启动一个协程，参数分别为调度器，执行的函数，以及启动方式, 比如我们启动了一个协程，deatched表示将协程对象分离出来，这种启动方式可以启动多个协程，他们都是独立的，如何调度取决于调度器，在用户的感知上更像是线程调度的模式，类似于并发运行，其实底层都是串行的。

```
co_spawn(io_context, listener(), detached);
```

我们启动了一个协程，执行listener中的逻辑，listener内部co_await 等待 acceptor接收连接，如果没有连接到来则挂起协程。执行之后的`io_context.run()`逻辑。所以协程实际上是在一个线程中串行调度的，只是感知上像是并发而已。  
3   当acceptor接收到连接后，继续调用co_spawn启动一个协程，用来执行echo逻辑。echo逻辑里也是通过co_wait的方式接收和发送数据的，如果对端不发数据，执行echo的协程就会挂起，另一个协程启动，继续接收新的连接。当没有连接到来，接收新连接的协程挂起，如果所有协程都挂起，则等待新的就绪事件(对端发数据，或者新连接)到来唤醒。

        tcp::socket socket = co_await acceptor.async_accept(use_awaitable);//加上协程关键字就可以写成同步风格
以前async_xx()里面都是回调函数，异步风格
==现在变成use_awaitable，必须搭配co_await==
   `std::size_t n = co_await socket.async_read_some(boost::asio::buffer(data), use_awaitable);`

`use_awaitable` 是 Boost.Asio 提供的一个特殊标记，用于将异步操作转换为可以被协程等待的形式。它是一个模板参数，使得 `async_accept` 返回一个可以被 `co_await` 等待的 `awaitable` 对象。

**`co_await`**
`co_await` 是 C++20 协程中的一个关键字，用于异步等待某个操作完成。它会暂停当前协程的执行，直到等待的操作完成。