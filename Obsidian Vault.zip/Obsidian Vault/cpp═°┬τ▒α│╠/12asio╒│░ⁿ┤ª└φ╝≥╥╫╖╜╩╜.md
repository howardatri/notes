这些逻辑写起来很复杂，所以我们可以通过读取指定字节数，直到读完这些字节才触发回调函数，那么可以采用async_read函数，这个函数指定读取指定字节数，==只有完全读完才会触发回调函数==。
## 获取头部数据

我们可以读取指定的头部长度，大小为HEAD_LENGTH字节数，只有读完HEAD_LENGTH字节才触发HandleReadHead函数



操作系统时间片开销
发送一直抢占线程
所以送要睡两秒  ==自己写不要sleep== 而是条件变量wait

其实就是session里分开了了原先一起的步骤：
先调用handlereadhead回调函数读取头部，这个函数最后读取完了调用readmsg回调函数读取消息体 ，readmsg最后读完了clearbuffer再次监听下一次，即调用handlereadhead回调