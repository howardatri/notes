## 封装redis操作类

因为hredis提供的操作太别扭了，我们手动封装redis操作类，简化调用流程。

封装的类叫RedisMgr，它是个单例类并且可接受回调，按照我们之前的风格
==注意redis里的传const char*!  `c_str()`==
#编程哲学 防御式编程-条件不成立就返回
```
class RedisMgr: public Singleton<RedisMgr>, 
    public std::enable_shared_from_this<RedisMgr>
{
    friend class Singleton<RedisMgr>;
public:
    ~RedisMgr();
    bool Connect(const std::string& host, int port);
    bool Get(const std::string &key, std::string& value);
    bool Set(const std::string &key, const std::string &value);
    bool Auth(const std::string &password);
    bool LPush(const std::string &key, const std::string &value);
    bool LPop(const std::string &key, std::string& value);
    bool RPush(const std::string& key, const std::string& value);
    bool RPop(const std::string& key, std::string& value);
    bool HSet(const std::string &key, const std::string  &hkey, const std::string &value);
    bool HSet(const char* key, const char* hkey, const char* hvalue, size_t hvaluelen);
    std::string HGet(const std::string &key, const std::string &hkey);
    bool Del(const std::string &key);
    bool ExistsKey(const std::string &key);
    void Close();
private:
    RedisMgr();

    redisContext* _connect;
    redisReply* _reply;
};
```

redis set返回status和"OK"字符串
### 回复类型说明
- **`REDIS_REPLY_STRING (1)`**：表示 Redis 返回了一个字符串类型的回复。这是最常见的回复类型之一，用于命令如 `GET`，当键存在时返回键的值作为字符串。
    
- **`REDIS_REPLY_ARRAY (2)`**：表示 Redis 返回了一个数组类型的回复。某些命令如 `LRANGE`（获取列表中的元素范围）会返回一个包含多个元素的数组。
    
- **`REDIS_REPLY_INTEGER (3)`**：表示 Redis 返回了一个整数类型的回复。例如，`DBSIZE` 命令返回数据库中键的数量，或 `INCR` 命令返回递增后的整数值。
    
- **`REDIS_REPLY_NIL (4)`**：表示 Redis 返回了空值，通常对应于 Redis 中的 `nil`。这通常出现在尝试获取一个不存在的键时，如使用 `GET` 命令访问一个不存在的键。
    
- **`REDIS_REPLY_STATUS (5)`**：表示 Redis 返回了一个状态回复，通常是表示命令执行成功或失败的信息。例如，`SET` 命令在成功时会返回状态 `"OK"`。
    
- **`REDIS_REPLY_ERROR (6)`**：表示 Redis 返回了一个错误信息，表明命令执行过程中出现了问题。例如，当执行一个错误的命令或对数据类型进行不正确的操作时，服务器会返回一个错误回复。

redis可做跨进程队列

hset二级哈希操作，有两种写法
`1 bool RedisMgr::HSet(const std::string& key, const std::string& hkey, const std::string& value);`方便处理字符串
`2bool RedisMgr::HSet(const char* key, const char* hkey, const char* hvalue, size_t hvaluelen);`(argv数组)方便处理二进制数据
```
    const char* argv[4];
    size_t argvlen[4];
    argv[0] = "HSET";
    argvlen[0] = 4;
    argv[1] = key;
    argvlen[1] = strlen(key);
    argv[2] = hkey;
    argvlen[2] = strlen(hkey);
    argv[3] = hvalue;
    argvlen[3] = hvaluelen;
```

`assert` 是 C++（以及许多其他编程语言）中的一个调试工具，用于在开发过程中检查程序中的条件是否为真。如果条件为假（即表达式的结果为 `false`），程序会终止并输出错误信息，指出断言失败的位置。这有助于开发者快速发现和定位问题。

getinstance只有实例化时安全，执行其他命令时有线程安全
↓
## 封装redis连接池
```
class RedisConPool {
public:
    RedisConPool(size_t poolSize, const char* host, int port, const char* pwd)
        : poolSize_(poolSize), host_(host), port_(port), b_stop_(false){
        for (size_t i = 0; i < poolSize_; ++i) {
            auto* context = redisConnect(host, port);
            if (context == nullptr || context->err != 0) {
                if (context != nullptr) {
                    redisFree(context);
                }
                continue;
            }

            auto reply = (redisReply*)redisCommand(context, "AUTH %s", pwd);
            if (reply->type == REDIS_REPLY_ERROR) {
                std::cout << "认证失败" << std::endl;
                //执行成功 释放redisCommand执行后返回的redisReply所占用的内存
                freeReplyObject(reply);
                continue;
            }

            //执行成功 释放redisCommand执行后返回的redisReply所占用的内存
            freeReplyObject(reply);
            std::cout << "认证成功" << std::endl;
            connections_.push(context);
        }

    }

    ~RedisConPool() {
        std::lock_guard<std::mutex> lock(mutex_);
        while (!connections_.empty()) {
            connections_.pop();
        }
    }

    redisContext* getConnection() {
        std::unique_lock<std::mutex> lock(mutex_);
        cond_.wait(lock, [this] { 
            if (b_stop_) {
                return true;
            }
            return !connections_.empty(); 
            });
        //如果停止则直接返回空指针
        if (b_stop_) {
            return  nullptr;
        }
        auto* context = connections_.front();
        connections_.pop();
        return context;
    }

    void returnConnection(redisContext* context) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (b_stop_) {
            return;
        }
        connections_.push(context);
        cond_.notify_one();
    }

    void Close() {
        b_stop_ = true;
        cond_.notify_all();
    }

private:
    std::atomic<bool> b_stop_;
    size_t poolSize_;
    const char* host_;
    int port_;
    std::queue<redisContext*> connections_;
    std::mutex mutex_;
    std::condition_variable cond_;
};
```
队列可以采用头尾锁队列

失败了既要freereply也要freeredis(前提是有reply)

重要:getConnection
```
    redisContext* getConnection() {
        std::unique_lock<std::mutex> lock(mutex_);
        cond_.wait(lock, [this] {
            if (b_stop_) {
                return true;
            }
            return !connections_.empty();//空的话false,那么线程挂起
            });
        //如果停止则直接返回空指针
        if (b_stop_) {
            return  nullptr;
        }
        auto* context = connections_.front();
        connections_.pop();
        return context;
    }
```
returnconnection:
- 检查 `b_stop_` 标志，如果连接池已经停止（`b_stop_` 为 `true`），则直接返回，不将连接返回到池中。
    
- 这种设计可以防止在连接池停止后，新的连接被错误地返回到池中。

```
1. `RedisMgr::RedisMgr() {`
2. `auto& gCfgMgr = ConfigMgr::Inst();`
3. `auto host = gCfgMgr["Redis"]["Host"];`
4. `_con_pool.reset(new RedisConPool(5, host.c_str(), atoi(port.c_str()), pwd.c_str()));`
5. `}`
```
1.	释放原有资源：如果 _con_pool 原本已经指向某个 RedisConPool 对象，reset 会先释放（delete）原有对象，防止内存泄漏。
2.	接管新资源：reset 会让 _con_pool 指向新的 RedisConPool 实例，负责其生命周期管理。
简而言之：
reset 用于安全地替换 unique_ptr 所管理的对象，并自动释放旧对象的内存。

小工具 ctrl+F 全部替换
==注意:hget和get里都要还回链接