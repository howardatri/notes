## 客户端TCP管理者(qt)

因为聊天服务要维持一个长链接，方便服务器和客户端双向通信，那么就需要一个TCPMgr来管理TCP连接。

而实际开发中网络模块一般以单例模式使用，那我们就基于单例基类和可被分享类创建一个自定义的TcpMgr类，在QT工程中新建TcpMgr类，会生成头文件和源文件，头文件修改如下

*经典inithandler方法注册回调*

接下来我们在构造函数中连接网络请求的各种信号

模型：不用阻塞的socket了，linux用epoll，windows用iocp

tcp结合tlv解决粘包问题

```
QObject::connect(&_socket, &QTcpSocket::connected, [&]() {
        qDebug() << "Connected to server!";
        // 连接建立后发送消息
        emit sig_con_success(true);
    });还是信号和槽(connect是qt提供的信号，槽就是回调函数)
    
    QObject::connect(&_socket, &QTcpSocket::readyRead, [&]() {
        // 当有数据可读时，读取所有数据(只要是可读了就会发)
        // 读取所有数据并追加到缓冲区
        _buffer.append(_socket.readAll());
```
append追加方式加入buffer缓存
mid从0截取到指定长度/指定长度截完->用于处理接收大于指定长度、

5.15以后的主流解决网络波动的方法、
```
    //5.15 之后版本
    //       QObject::connect(&_socket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::errorOccurred), [&](QAbstractSocket::SocketError socketError) {
    //           Q_UNUSED(socketError)
    //           qDebug() << "Error:" << _socket.errorString();
    //       });
```
这段代码使用 Qt 5.15（及以后版本）的新语法，把 **`QTcpSocket` 的错误信号** 连接到一个 **lambda 槽函数** 上，实现 **异步错误捕获**。
以前要cast:
### ✅ 一句话总结

> **因为 `error` 有两个重载，老 Qt 必须用 `static_cast` 指定要哪一个；新版改名为 `errorOccurred`，就省掉了 cast。**


inithandler注册消息(放入形参λ表达式)

handlemsg根据id找到并传参使用回调函数时是qmap
qmap可以直接迭代器使用value()方法

连接的槽函数
`slot_tcp_connect` 只是 **把“界面告诉我要连哪台服务器”翻译成“socket 实际去连”** 的入口槽函数。
连完才有构造函数里的connect
![[Pasted image 20250723213230.png]]
也就是说先是界面触发了信号给connect槽函数，槽函数启动再执行构造函数最开始的connect里的拉姆达表达式回调

# 注意
开头构造函数里把 **“上层 → 发数据”** 和 **“收到数据 → 解析”** 两条通路全部打通，形成完整的网络通信闭环。
```
    //连接发送信号用来发送数据
    QObject::connect(this, &TcpMgr::sig_send_data, this, &TcpMgr::slot_send_data);
    //注册消息
    initHandlers();
}
```
为什么要信号槽机制发送数据？保证发送队列统一处理
还不一样，传统的三参数connect是直连，像刚刚发送数据闭环的四参数才是队列？


然后修改LoginDialog中的initHandlers中的收到服务器登陆回复后的逻辑，这里发送信号准备发起长链接到聊天服务器

在LoginDialog构造函数中连接信号，包括建立tcp连接，以及收到TcpMgr连接成功或者失败的信号处理

# 前情提要
inithandler里为什么没一开始共享智能指针:前提是类构造完，但显然类没构造完

先建立连接再传输消息
发送连接成功信号->调用连接成功槽函数发送登录请求->tcpmgr发送数据
->


slot_send_data里的流
![[Pasted image 20250723220953.png]]


介绍了下大端小端
