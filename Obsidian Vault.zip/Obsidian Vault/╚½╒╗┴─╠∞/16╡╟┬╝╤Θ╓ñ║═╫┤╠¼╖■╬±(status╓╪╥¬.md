微调界面
rc.qrc导入资源

我们先实现客户端登录,为登录按钮添加槽函数响应

增加检测函数
在HttpMgr中添加sig_login_mod_finish信号，收到http请求完成回包的槽函数中添加登录模块的响应，将登录模块的消息发送到登录界面

在LoginDialog的构造函数中添加消息对应的槽函数连接
initHttpHandlers为初始化http回调逻辑, 并添加_handlers成员

## GateServer完善登陆逻辑

在LogicSystem的构造函数中添加登陆请求的注册。

==sql注意 ==
````cpp
pstmt->setString(1, email);
````
这里是防止sql注入，把过程语句
`SELECT * FROM user WHERE email = ?`理解成
`SELECT * FROM user WHERE email = [填空]

这个 `?` 是一个 **占位符**，**第 1 个问号** 对应 `setString(1, email)`。

`setString(1, email)` 就是把 `[填空]` 填成用户输入的邮箱
数字 `1` 表示第 **1** 个问号，**从 1 开始计数**（不是从 0）。
如果是多个问号，比如：
```sql
SELECT * FROM user WHERE email = ? AND pwd = ?
```
就要写：
```cpp
pstmt->setString(1, email);
pstmt->setString(2, pwd);
```


更新message.proto,增加信息包配置
我们用下面两条命令重新生成pb.h和grpc.pb.h

实现StatusGrpcClient:
1连接池:和以前一样，host和端口创建连接，然后放入连接池
2
#注意线程 37:02 关于线程挂起与lambda表达式返回true/false的问题解释

3然后实现cpp:构造函数/
getchatserver:stub是grpc的函数
login(这集还没实现但先拷贝过来了)

一遍过编译

## StatusServer状态服务

我们要实现状态服务，主要是用来监听其他服务器的查询请求, 用visual studio创建项目，名字为StatusServer.

io_context用的是阻塞的，所以不能和主线程一起(主线程是grpc的服务器)
新建线程+detach

把gateserver里的文件复制过来
主要是新增的statusserviceiml这个实现
#grpc特性 设置好了port host啥的就会自动返回客户端，是grpc底层实现的


hardcoding为 `_servers初始化   ！！！`自己设的两个聊天服务器
‘’
`con_count` 就是 **当前已经连接到这台聊天服务器的客户端数量**（connection count 的缩写）


排查思路
