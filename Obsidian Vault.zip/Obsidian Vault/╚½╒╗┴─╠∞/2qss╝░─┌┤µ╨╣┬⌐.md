这里好像是因为  设置为主窗口之后 setcentralwidget 关闭的时候会qt会自动删除注册窗口但是 在主窗口的析构函数中又一次的删除了所以才会不正常退出】

指定父窗口
但是这样是独立的
得同宽  嵌进来
  `_login_dlg->setWindowFlags(Qt::CustomizeWindowHint|Qt::FramelessWindowHint);课外知识点`
  那么就不要login_dlg->show()了，而是把后一个先隐藏



qss呢？
想实现err_tip颜色改变，一方面要在qss里写上状态及对应逻辑
另一方面需要实现一个全局刷新e
==err_tip一定要设置属性，不然不知道几种状态==

1. **`setProperty("state", "normal")`**
    - 这里 `"state"` 是你自己定义的属性名（可以任意命名，如 `"status"`、`"mode"` 等）。
    - `"normal"` 是你赋予该属性的值（同样可以自定义，如 `"error"`、`"warning"` 等）。
**确保属性和 QSS 匹配**
- **方法 1（推荐）**：统一使用 `state` 作为属性名，QSS 里用 `[state="xxx"]`：

接着实现邮箱正则匹配
