这期的中间件版本都别搞最新的，不然会起冲突，目前成功编译grpc的一套方案： cmak v3.31.6 官网可以下(不是最新版) 
grpc v1.34.0 根据文档下的(用的git) 
go v1.24.0 官网下的(最新的) 
perl v5.16.2 根据文档里的网盘地址下的 
nasm v2.16.0 官网下的(不是最新版)


## proto文件编写

在项目的根目录下创建一个proto名字为message.proto
```
syntax = "proto3"; 
package message; 
service VarifyService { 
rpc GetVarifyCode (GetVarifyReq) returns (GetVarifyRsp) {} }
message GetVarifyReq { string email = 1; } 
message GetVarifyRsp { int32 error = 1; string email = 2; string code = 3;
```
这后面的req和rsp都是消息类型，而get是服务定义
**生成代码**
使用 Protobuf 编译器（`protoc`）可以将 `.proto` 文件编译成目标语言的代码（如 C++、Java、Python 等）。生成的代码中会包含：

- 服务接口的定义。
    
- 请求和响应消息的类定义。
    
- 序列化和反序列化方

与后面server.js里实现get高度相关



我们新建一个VarifyGrpcClient类，vs帮我们自动生成头文件和源文件，我们在头文件添加Grpc客户端类
`std::unique_ptr<VarifyService::Stub> stub_;`stub可以看成信使

我们在之前收到post请求获取验证码的逻辑里添加处理
regpost里不是简单回包，而是
```
		GetVarifyRsp rsp = VerifyGrpcClient::GetInstance()->GetVarifyCode(email);
		std::cout<< "email is " << email << std::endl;
		root["error"] = rsp.error();
```
## 服务器读取配置

我们很多参数都是写死的，现通过配置文件读取以方便以后修改  
在项目中添加config.ini文件

添加ConfigMgr类用来读取和管理配置, 定义一个SectionInfo类管理key和value

定义ComigMgr管理section和其包含的key与value

构造函数里实现config读取
==默认构造最难搞==



其他地方想要获取配置信息就不需要定义了，直接包含const.h并且使用gCfgMgr即可。



## 总结

本节基于visual studio配置grpc，并实现了grpc客户端发送请求的逻辑。下一节实现 grpc server


no，报错了 非常低级的错误，库包含路径整成cmake里的