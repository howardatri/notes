## 完善proto

在proto文件里新增登陆验证服务


statusserver管两个:1client-登录->gate->status(返回ip+token给gate)
2client-给token ip登录->chat->status->chat->rsp回包登录
```
客户端 → Gate(HTTP) → Status(LoginCreate) → 回{ip,token}
客户端 → Chat(TCP) → Status(ValidateToken) → Chat → 回登录结果
```


发送:
slot_http_finish->各自模块的槽->handler->(登录)释放tcp连接信号(传入serverinfo)
->连接tcp管理者槽函数 建立连接->连接回调成功发送成功连接成功信号->给逻辑层
->连接登陆界面槽函数->构造json发送tcp请求给tcp管理者(chat ser) 信号senddata->
senddata槽函数先标准化数据(utf8数组 网络字节序长度 qbytearray存储待发送数据和数据流 -流（由qbytearrr创建，写入id 长度） qbytearray append添加data )->利用socket写入

回包:
readyread->读取所有数据并追加到缓冲区(readAll)->处理头部信息 处理body(分割->
调用handlemsg(传入id 长度 msg)->id为login_rsp的handler  需要用到数据管理类usermgr(未实现)->发送跳转界面信号



不直接调tcp:利用信号队里额实现排队效果！


#grpc grpc详解
**`.proto` 只是“接口合同”，`protoc` 把它翻译成 C++（或其他语言）真正能编译、能调用的代码；生成的 `.pb.cc / .pb.h` 里已经帮你做好了序列化、反序列化、网络传输的所有脏活，所以你“直接 include 就能用”。**
1写 `.proto` —— 只写“要什么”
```
service StatusService {
    rpc Login(LoginReq) returns (LoginRsp);
}
```
2跑 `protoc` —— 把合同翻译成“包工队”
``protoc --cpp_out=. --grpc_out=. --plugin=protoc-gen-grpc=`which grpc_cpp_plugin` message.proto``
这一步产出：  
• `message.pb.h / .pb.cc`：把每个 message 变成 C++ 类，带 `SerializeAsString()` / `ParseFromString()`。  
• `message.grpc.pb.h / .grpc.pb.cc`：生成 **stub**（客户端）和 **service**（服务器端）骨架代码
```
class StatusService::Stub {
    Status Login(ClientContext*, const LoginReq&, LoginRsp*);
}
class StatusService::Service {
    virtual Status Login(ServerContext*, const LoginReq*, LoginRsp*) = 0;
}
```
3你填业务 —— 只补“真正干活的函数体”

4gRPC 底层 —— 全自动完成  
    • 帮你把 `LoginReq` 序列化成二进制帧 → HTTP/2 发给服务器。  
    • 服务器收到后自动反序列化 → 调你的 `Login()` 实现。  
    • 回包再序列化 → 发回客户端 → 自动反序列化进 `LoginRsp`。  
    • 连接复用、流控、压缩、TLS、重试、负载均衡……全内置。

类比总结  
`.proto` 就像 **函数声明**；  
`protoc` 生成的 `.pb.cc/.grpc.pb.cc` 就像 **帮你写好了 socket、打包、拆包、线程池的“胶水层”**；  
你只需写 **函数体** 和 **一行 stub 调用**，其他全部托管。


getchatserver
—— 这是 **gRPC 服务接口的实现函数**，负责把结果填进 `reply`，然后 `return Status::OK;`。  
只要函数正常返回，`grpc` 框架就会自动把 `reply` 序列化并通过 **HTTP/2** 回发给客户端；**reply 的“发出”发生在 return 之后，由 gRPC 底层完成**，你不需要再手动 send。



![[Pasted image 20250725224458.png]]
一句话总结  
**客户端的两个 stub 函数** = 发请求；  
**服务端的两个 `Status` 函数** = 真正干活的 gRPC 业务实现；  
其余工具函数只为这两个业务函数提供“负载均衡”和“token 存储”能力。
|
