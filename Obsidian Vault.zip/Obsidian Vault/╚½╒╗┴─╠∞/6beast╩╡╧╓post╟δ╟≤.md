上一集实现了get,但是不能带参数
所以对于get请求带参数的情况我们要实现参数解析，我们可以自己实现简单的url解析函数
先字符转换
接下来我们实现url编码工作
我们先判断str[i]是否为字母或者数字，或者一些简单的下划线，如果是泽直接拼接，否则判断是否为空字符，如果为空则换成'+'拼接。否则就是特殊字符，我们需要将特殊字符转化为'%'和两个十六进制字符拼接。现拼接'%'，再将字符的高四位拼接到strTemp上，最后将低四位拼接到strTemp上。

url解码的工作正好相反

接下来实现get请求的参数解析, 在HttpConnection里添加两个成员
`std::string _get_url;
`std::unordered_map<std::string, std::string> _get_params;`
参数解析如下PreParseGetParam

HttpConnection::HandleReq函数略作修改

我们修改LogicSytem构造函数，在get_test的回调里返回参数给对端
```
LogicSystem::LogicSystem() {
    RegGet("/get_test", [](std::shared_ptr<HttpConnection> connection) {
        beast::ostream(connection->_response.body()) << "receive get_test req " << std::endl;
        int i = 0;
        for (auto& elem : connection->_get_params) {
            i++;
            beast::ostream(connection->_response.body()) << "param" << i << " key is " << elem.first;
            beast::ostream(connection->_response.body()) << ", " <<  " value is " << elem.second << std::endl;
        }
    });
}
### **`beast::ostream`**
`beast::ostream` 是一个用于向 HTTP 响应体中写入内容的工具。它类似于标准库中的 `std::ostream`，但专门用于操作 HTTP 响应体
```


# 处理post请求并解析json数据

## 注册Post请求
我们实现RegPost函数
在const.h中添加ErrorCodes定义并且包含JsonCpp相关的头文件
然后在LogicSystem的构造函数里添加获取验证码的处理逻辑

` connection->_response.set(http::field::content_type, "text/json");`
在 HTTP 响应中设置 `Content-Type` 头时，双引号中的值并不是完全随意的，而是需要遵循 HTTP 协议中定义的 MIME 类型（也称为媒体类型）。`Content-Type` 头用于告诉客户端响应体的媒体类型，以便客户端正确解析和显示响应内容

//参数解析错误也不要返回false？  ==不知真假==
//tcp面向字节流

然后我们在LogicSystem中添加Post请求的处理(handlepost)


在HttpConnection的HandleReq中添加post请求处理


## 客户端增加post逻辑

我们之前在客户端实现了httpmgr的post请求，在点击获取验证码的槽函数里添加发送http的post请求即可
## 客户端配置管理

我们发现客户端代码中很多参数都是写死的，最好通过配置文件管理，我们在代码所在目录中新建一个config.ini文件, 内部添加配置