
我们为了实现点击界面某个位置判断是否隐藏搜索框的功能。我们期待当鼠标点击搜索列表之外的区域时显示隐藏搜索框恢复聊天界面。 点击搜索列表则不隐藏搜索框。可以通过重载ChatDialog的EventFilter函数实现点击功能


标准参数
`bool eventFilter(QObject *watched, QEvent *event) override ;`
具体判断全局鼠标按下位置和功能

```
void ChatDialog::handleGlobalMousePress(QMouseEvent *event)
{
    // 实现点击位置的判断和处理逻辑
    // 先判断是否处于搜索模式，如果不处于搜索模式则直接返回
    if( _mode != ChatUIMode::SearchMode){
        return;
    }

    // 将鼠标点击位置转换为搜索列表坐标系中的位置
    QPoint posInSearchList = ui->search_list->mapFromGlobal(event->globalPos());
    // 判断点击位置是否在聊天列表的范围内
    if (!ui->search_list->rect().contains(posInSearchList)) {
        // 如果不在聊天列表内，清空输入框
        ui->search_edit->clear();
        ShowSearch(false);
    }
}
```
在ChatDialog构造函数中添加事件过滤器

```
//检测鼠标点击位置判断是否要清空搜索框
this->installEventFilter(this); // 安装事件过滤器

//设置聊天label选中状态
ui->side_chat_lb->SetSelected(true);
```
默认搜索是选中状态


这样就可以实现在ChatDialog中点击其他位置隐藏SearchList列表了。

## 查找结果

在项目中添加FindSuccessDlg设计师界面类，其布局如下
![[Pasted image 20250805171253.png]]

我们希望无边框

```
// 设置对话框标题

    setWindowTitle("添加");

    // 隐藏对话框标题栏

    setWindowFlags(windowFlags() | Qt::FramelessWindowHint);
    this->setObjectName("FindSuccessDlg");

    // 获取当前应用程序的路径

    QString app_path = QCoreApplication::applicationDirPath();

    QString pix_path = QDir::toNativeSeparators(app_path +

                             QDir::separator() + "static"+QDir::separator()+"head_1.jpg");
```
为什么头像不用qss?后面要链接配合https下载


老朋友模态对话框setModal(true);
把当前窗口 **设为“模态对话框”**，也就是：

> **当它弹出来后，用户必须先处理完它（关闭或完成交互），才能再点其他窗口。**

设置下qss

在SearchList 的slot_item_clicked函数中添加点击条目处理逻辑
先变item为widget
`QWidget *widget = this->itemWidget(item); // 获取自定义widget对象`
再转为基类，我们好操作 方法
`    // 对自定义widget进行操作， 将item 转化为基类ListItemBase

    ListItemBase *customItem = qobject_cast<ListItemBase*>(widget);

    if(!customItem){

        qDebug()<< "slot item clicked widget is nullptr";

        return;

    }`
判断类型
`    auto itemType = customItem->GetItemType();

    if(itemType == ListItemType::INVALID_ITEM){

        qDebug()<< "slot invalid item clicked ";

        return;

    }`

#注意 普通指针dynamic_cast,智能指针dynamic_pointer_cast
````
    if(itemType == ListItemType::ADD_USER_TIP_ITEM){

        //todo ...
        _find_dlg = std::make_shared<FindSuccessDlg>(this);
        auto si = std::make_shared<SearchInfo>(0,"llfc","llfc","hello , my friend!",0);
        (std::dynamic_pointer_cast<FindSuccessDlg>(_find_dlg))->SetSearchInfo(si);
        _find_dlg->show();
        return;
    }
````
这里就调用界面了，向下转型
(`    std::shared_ptr<QDialog> _find_dlg;`)



这样我们在输入框输入文字，点击搜索列表中搜索添加好友的item，就能弹出搜索结果对话框了。这里只做界面演示，之后会改为像服务器发送请求获取搜索结果。

## pro的改写

我们对项目的pro做了调整，更新了static文件夹的拷贝以及编码utf-8的设定
