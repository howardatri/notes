
## ChatServer

一个TCP服务器必然会有连接的接收，维持，收发数据等逻辑。那我们就要基于asio完成这个服务的搭建。主服务是这个样子的

信号复习
template <typename... SignalNumbers>
signal_set(boost::asio::io_context& io_context,
           SignalNumbers... signal_numbers);

先看一遍吧


ioservices这个vector什么时候构造？在构造函数给定容量初始化的时候

```
_works[i] = std::unique_ptr<Work>(new Work(_ioServices[i]));
```
| 动作                           | 含义                                    |
| ---------------------------- | ------------------------------------- |
| `new Work(_ioServices[i])`   | 创建一个 **work 实例并绑定到第 i 个 io\_context** |
| `std::unique_ptr<Work>(...)` | 把裸指针包成 `unique_ptr`                   |
| `_works[i] = ...`            | 把独占指针放进 `_works[i]`                   |

```
for (std::size_t i = 0; i < _ioServices.size(); ++i) {
    _threads.emplace_back([this, i]() {
        _ioServices[i].run();   // 事件循环
    });
}
```
| 元素                     | 作用                                         |
| ---------------------- | ------------------------------------------ |
| `_threads`             | `std::vector<std::thread>`，用来保存工作线程        |
| `emplace_back(...)`    | 就地创建线程，避免拷贝                                |
| `[this, i]`            | lambda 捕获：需要访问成员变量 `_ioServices` 和当前索引 `i` |
| `_ioServices[i].run()` | **阻塞式事件循环**，不断分发异步任务（读/写/定时器等）             |
服务停了还需要线程join
cserver
acceptor asio要求我们这么写

流程
![[Pasted image 20250724173905.png]]

accept调用成员函数需要把自身传过去

tcp与http原理
![[Pasted image 20250724175411.png]]

csession
先读取头部,头部里调用封装的完整读四字节函数
asyncreadfull调用了asyncreadlen(指定长度)这玩意再调用asio底层的readsome
//读取指定字节数
```
//读取指定字节数
void CSession::asyncReadLen(std::size_t read_len, std::size_t total_len, 
	std::function<void(const boost::system::error_code&, std::size_t)> handler)
{
	auto self = shared_from_this();
	_socket.async_read_some(boost::asio::buffer(_data + read_len, total_len-read_len),
		[read_len, total_len, handler, self](const boost::system::error_code& ec, std::size_t  bytesTransfered) {
			if (ec) {
				// 出现错误，调用回调函数
				handler(ec, read_len + bytesTransfered);
				return;
			}

			if (read_len + bytesTransfered >= total_len) {
				//长度够了就调用回调函数
				handler(ec, read_len + bytesTransfered);
				return;
			}

			// 没有错误，且长度不足则继续读取
			self->asyncReadLen(read_len + bytesTransfered, total_len, handler);
	});
}
```
详解bytetransfered:根本不重要
![[Pasted image 20250724224126.png]]
**handler**  
一个可调用对象，签名必须是
```
void handler(const boost::system::error_code& ec,
             std::size_t bytes_transferred);
```

`_data在readsome那会已经被读取(buffer注入)，后面处理的时候可直接memcpy`

这个嵌套+handler真的难读

发送数据
阻塞可以for循环，但是异步不行

异步需要队列组织
队列保证异步操作有序性，所以需要构造逻辑队列

调用回调才是真的发送完，所以在回调里处理队列能保证发送的有序

logicsystem(自己有一个工作线程)
csession投递，投递时通知(notify)====》生产者消费者模型==
```
void LogicSystem::PostMsgToQue(shared_ptr < LogicNode> msg) {
	std::unique_lock<std::mutex> unique_lk(_mutex);
	_msg_que.push(msg);
	//由0变为1则发送通知信号
	if (_msg_que.size() == 1) {
		unique_lk.unlock();
		_consume.notify_one();
	}
}
```

```
Json::Value rtvalue;
Defer defer([this, &rtvalue, session] {
    std::string return_str = rtvalue.toStyledString();
    session->Send(return_str, MSG_CHAT_LOGIN_RSP);
});
```
• `rtvalue` 准备回包 JSON。  
• `Defer` 是一个 **RAII** 小工具：函数**任何路径**退出时都会把 `rtvalue` 序列化并 `Send` 回客户端，保证不遗漏。


• `_users` 是 **运行时内存哈希表**，缓存已加载的玩家信息，减少 DB 访问。
```
if (find_iter == _users.end()) {
    // 内存里没有，查数据库
    user_info = MysqlMgr::GetInstance()->GetUser(uid);
    if (user_info == nullptr) {
        rtvalue["error"] = ErrorCodes::UidInvalid;
        return;                   // DB 里也查不到，告诉客户端 UID 不存在
    }
    _users[uid] = user_info;      // 查到后放进缓存
} else {
    user_info = find_iter->second; // 已在缓存，直接复用
}
```
整个流程一句话总结：  
**解析登录 JSON → 远程校验 token → 缓存/DB 取玩家信息 → 拼装结果 → 保证一定回包给客户端。**

![[Pasted image 20250725230211.png]]