
## lec 14 disjoint set并查集
"dynamic connectivity"

disjoint set has two operations:
- connect(x,y) :connects x and y
- isConnected(x,y) : returns true if x and y are connected(can be transitive,they don't need to be direct)


To keep things simple, we're going to:
1.Force all items to be integers instead of arbitrary data (e.g. 8 instead of USA)
2.Declare the number of items in advance, everything is disconnected at start.
### goal: design an efficient disjoint set implementation

#### naive approach:  XXX No!
1.Connecting two things: Record every single connecting line in some data structure.
2.Checking connectedness: Do some sort of (??) iteration over the lines to see if one thing can be reached from the other.

ah ha: Rather than manually writing out every single connecting line, only record the sets that each item belongs to. like:

![[Pasted image 20251004154513.png]]

#### 1 list of sets?
`List<Set<Integer>>`
very intuitive idea ,but actually ==terrible!==
require iterating through all the sets to find anything.

#### 2 quick find `ds`
another: 一个数组记录一个共同的入口i,直接查数字对应数组是否相同Θ(1)。但是连接操作是O(n),要把一个组的都改了
这种是快速寻找并查集 
####  3 quick union
Hard question: How could we change our set representation so that combining two sets into their union requires changing one value?
ldea: ==Assign each item a parent (instead of an id). Results in a tree-like shape. ==
An innocuous sounding, seemingly arbitrary solution.
Unlocks a pretty amazing universe of math that we won't discuss.
这里是，每一个第一次出现的树的值为-1，然后connect的两个，后者的值是前者
![[Pasted image 20251004160327.png]]
connect (5,2)
How should we change the parent list to handle this connect operation?
 if you are not sure where to start, consider why can't we just set id[5] to 2?

climb the tree!
set 5's root to 2's root(through out whole the two trees)
 连接：通过爬树，把两个元素的根值连接

worst: 只有左子树或只有右子树，那就要爬完整个高度
所以我们要做一些改进
#### 4 weighed quick union :weight for items
one possible approach is keep track of the height of every tree
- line up shorter tree below the lager tree
- in case of a tie ,break tie arbitrarily
Unfortunately , tracking height is kind of annoying

but size a.k.a weight works just as well asymptotically
(number of elements)
这里还不是高度，就是简单的节点数量，不好 
Modify quick-union to avoid tall trees
Track tree size (number of elements).
==New rule: Always link root of smaller tree to larger tree.==
 把小的树加到大的树下面
![[Pasted image 20251004162347.png]]
所以在那个数组里，负数代表为根，负数的绝对值代表树的大小，而其他的表示自己的父节点  这是第一种方法
Minimal changes needed:
- Use parent[] array as before.
- `isConnected(int p,int q)` requires no changes
- `connect(int p,int q)` needs to somehow keep track of sizes.
    -- See the old Disjoint Sets lab for the full details.

Two common approaches:
1.Replace -1 with -weight for roots (top approach)
2.Create a separate size array (bottom approach).

![[Pasted image 20251004162651.png]]

weighed quick union ‘s performance:
worst case tree height is Θ(log N)

##### possible approach:height
One possible approach is to keep track of the height of every tree.
- Link up shorter tree below the larger tree.
- In case of a tie, break tie arbitrarily.
Unfortunately, tracking tree height is kind of annoying.
Interestingly, tracking the tree's “size", a.k.a. “weight" works just as well asymptotically.
Size and weight both mean the total number of items in that tree.

## lec14 续 

#### 5 `WQU` with path compression (after `WQU`): a clever idea

idea: when we do `isConnected`,tie all nodes seen to the root.
d
#非纯函数 （Impure Function）是指那些==与函数参数和返回值之外的外界环境进行隐式数据交换的函数==。 这意味着非纯函数可能会修改全局变量、进行输入/输出操作（如读写文件、打印到屏幕），或依赖于随时可能改变的外部状态（如DOM元素属性），导致相同的输入可能会产生不同的输出。

By compressing the tree with each union and `isConnected` called, we keep the tree short.

Done! Such quick union and path compression is what the standard way disjoint sets are implemented today.

 惰性展开(WQU) > 主动更新(quick find)


## lec15 asymptotics Ⅱ
goal: go over a few examples of how you might compute some asymptotics

exp1:
	外层循环i * 2 <N，内层j<i&& j+=1
	这个是θ(N)    (实际上是公比为2的等比数列求和，我们用N替代2^k)  

### there is no magic shortcut for analysis
![[Pasted image 20251005104524.png]]
注意K次等差，复杂度为θ(q^k+1) !
黎曼和积分？

为什么能把后两个换成θ(N)?

这种换元是合法的，但你必须清楚地区分“问题规模 N”和“循环次数/项数 Q”这两个不同的变量。
在算法分析中，**N 必须始终代表“输入规模”**。

 为什么可以这样替换？
 
在算法分析中，我们经常关心**输入规模 N**。对于：
- **循环次数 Q** 与 **问题规模 N** 的关系是：N = 2ᵠ（分治算法中常见）或Q = log₂N
- 此时，总工作量就是 Θ(N) 而不是 Θ(Q)

其实就是对f(x)积分

### amortized runtime摊销运行时间
after `addlast` runtime vs. each `addlast` runtime

摊还分析不是关注**单次操作**的最坏情况，而是关注**连续执行一系列操作**的平均性能
**比喻**：  
一顿昂贵的大餐（最坏情况单次操作）如果被很多人分摊，那么每个人平均花费（摊还成本）并不高。

This is known as Amortized Runtime
- Any single operation may take longer, but if we use it over many operationswe're guaranteed to have a better average performance
- So amortized runtime gives a better estimate of how much time it takes touse something in practice
- Disjoint sets also used amortized runtime; WQU with path compression stillhas e(log(n)) runtime in the worst case, but ◎(a(n))amortized runtime.
 并查集（带路径压缩）
- `find` 操作的最坏情况是 O(logN)
- 但经过 M 次操作的摊还分析是 O(α(M))，其中 α 是反阿克曼函数

### recursive analysis

fibonacci
黄色的代表基本情况，黄色节点的值加起来就是根节点的值
绿色的是所有加法执行的时候，那么他的数量正好就是根节点值-1/-2
![[Pasted image 20251006115508.png]]
O(2^n)  θ(1.618^n) Ω(1.414^n)

#### binary search
 

#化简公式 floor和ceiling还有log的底数都无关
for aesthetic reason we write Log N

#### Merge Sort
`Mergesort` is a recursive way to sort a list:
- Split the list into two parts
- Sort the two lists individually
- Merge the two lists together


![[Pasted image 20251006121352.png]]

![[Pasted image 20251006121922.png]]
简化 计算时间
```
static void sortRuntime(int n){
sortRuntime(n/2);
sortRuntime(n/2);
// n units of work
}
```
Θ(N log N )




