### goal : measuring code efficiency
efficiency comes in two flavors:
- programming costs(not today)
- execution costs(memory and time )


