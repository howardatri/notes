`ADTs`
An Abstract Data Type  is defined only by its operations, not by it's implementation.
(disjoint set map set list)
next we are going to build sets and maps,the underlying ADT is tree.

### binary search trees

#### derivation
start with ordered link list
how do i  do  `contains` with less time?
let sentinel in the middle ,and change the left list's iteration
![[Pasted image 20251006124011.png]]
that' s what called ==trees==
#### definition(已在离散数学中学过)

in a rooted binary tree, every node has either 0,1 or 2 children(sub-trees)
##### ==BST property==
for every node x in the tree:
every key in the left sub-tree is less than x's key. just in case for right.

#### contains
搜索值小于当前值去左子树，大去右子树

#### insert
search for key.
- if found do nothing.
- if not found :
	- create new node → set appropriate link(小左右大)
```
static BST insert(BST T , key ik){
	 if(T == null){
	 return new BST(ik);
	 }
	 if(ik<T.key){
	 T.left = insert(T.left,ik);
	 }
	 else if (ik> T.right){
	 T.right = insert(T.right , ik);
	 }
	 return T;
}
```
相信你的递归! 多余的处理说明你没走到基本情况
避免arms length recursion ：A common rookie bad habit to avoid:
```
if (t.left == null) t.left = new BST(ik);
if (t.right == null) t.right = new BST(ik);
```

#### hibbard deletion
3 cases:
- delete those with no children: easy
消除指向，自动回收

- delete has one child
![[Pasted image 20251007160640.png]]
**把唯一的那个孩子节点返回出去**，**调用方（父节点）把自己的 left 或 right 指针直接指向这个孩子**
    parent
       |
      [x]        ← 待删节点
        \
       right
```
java
else return x.right;   // 情况 B 只有右孩子
```
返回的是 **right 节点本身**（不是它的值，是整个对象引用）。  
父节点的那一句：
````java
if (cmp < 0) x.left  = deleteNode(x.left,  key);
````
此时 `x.left` 原来指向 `[x]`，`deleteNode` 把 `[x]` 传进去，得到返回值 `right`，于是 **父节点的 left 字段瞬间改成指向 `right`**——树形结构就这样“提上来”了，没有任何拷贝或新建。


- delete has two children
 ![[Pasted image 20251007163914.png]]
选择待删除节点前驱节点/后驱节点(前驱就是左子树最大，后驱就是左子树最小)
为新根，那么该节点左边都比目标节点小

解释
情况 C 的两步拆解
1. 先找到右子树的最小节点 `successor`（它一定**最多只有右孩子**，所以删它时必然落入情况 A 或 B）。
    
2. 把 `successor` 的值拷进待删节点 `x`，问题变成“去右子树删掉那个 `successor` 节点”——这一步就是普通的递归调用 `deleteNode(x.right, successor.key)`，而 `deleteNode` 内部又会回到情况 A/B 的“直接返回孩子”逻辑，同样用一次赋值就把 `successor` 从树里摘掉了。

### sets and maps (the same thing)
 ![[Pasted image 20251007165055.png]]
建立键值对映射
#tips for lab
![[Pasted image 20251007165326.png]]

### `bst` implementation tips
			↑


## lec17 b tree
### bst height, big O vs. big θ

Height and average depth are important properties of BSTs.
The “depth" of a node is how far it is from the root, e.g. depth(g)= 2.
The “height" of a tree is the depth of its deepest leaf, e.g. height(T) = 4.
The “average depth" of a tree is the average depth of a tree's nodes.

good news :
BSTs have great performance if we insert items randomly.
bad news:
we can't always insert our items in a random order(like date).

in this lec , we'll do something totally different.

### B-Trees
### splitting juicy nodes
avoiding imbalance 
如果连续加17 18 19绝对不平衡(一条树)
problem : adding new leaves at the bottom.


==crazy idea:== never add new leaves at the bottom.
what if?
Avoid new leaves by “overstuffing" the leaf nodes.“Overstuffed tree" always has balanced height because leaf depths never change.
Height is just max(depth).

↑ if we have more to add (20 21 22)
介绍了优化方法:限制每个节点溢出数量，然后分裂满了的节点   
移动==中左== 节点为父节点
三个子树/更多
![[Pasted image 20251007171841.png]]
然后继续加，直到产生对根节点的链式反应
### chain reaction splitting

![[Pasted image 20251007214417.png]]
![[Pasted image 20251007214520.png]]
chain？ still!

### B-tree Terminology
such splitting tree called ==B Trees==
2-3 b-trees 2-3-4 b-trees:
- B-trees of order L=3,(like we used today) are also called a 2-3-4 tree or a 2-4tree.
(“2-3-4" refers to the number of children that a node can have, e.g. a 2-3-4 tree node may have 2, 3, or 4 children.)
- B-trees of order L=2 are also called a 2-3 tree.

**Usage: 1 small l: BST
2 very large : filesystem and database
### Invariant

Because of the way B-Trees are constructed, we get two nice invariants:
- All leaves must be the same distance from the root.(把节点同时推下来一层)
- A non-leaf node with k items must have exactly k+1 children.(items 与子树交替排列)
```
Example: The tree given below is impossible.
Leaves ([1]and [5 6 7]) are a different distance from the source.
Non-leaf node [2 3] has two items but only only one child. Should have0three children.
```


### Worst case performance


node和item不同？对

依旧O(log n)






