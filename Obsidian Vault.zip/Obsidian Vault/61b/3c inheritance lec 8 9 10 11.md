# lec8 interface and implementation
## Ⅰ interface and implementation

instead of using class , define with interface
```
public interface List61B<XXX>{
	
}
```
then use implements
```
public class Alist<XXX> implements Lists61B<XXX>{
}
```

调用的方法直接传接口`List61B`就行了

so called  =="interface inheritance"==

## Ⅱ implementation inheritance

use ==default==? to specify a method that subclasses should inherit form an 'interface'

```
public interface xx xx{

deault public void print(){
}

}
```
如何实现？用接口里其他必须实现的方法  妙啊

对default不满意？
override!

still use with ==super==

## Ⅲ static & dynamic type
compile-time type(static)
run-time(dynamic)


Suppose we call a method of an object using a variable with:
- compile-time type X
- run-time type X
Then if Y overrides the method, Y's method is used instead.
This term is a bit obscure.

This is known as =="dynamic method selection".==


# lec9 extends- casting- higher function(not include)
extends
```
class sllist;
class rotatingsllist<X> extends sllist<X>;
```

How do you know which to pick between “implements" and “extends"?
- You must use "implements" if the hypernym is an interface and the hyponymis a class (e.g. hypernym List, hyponym AList).
- You must use “extends" in all other cases.


how do i use the father class's private function or variant?
super!
```
public item removelast(){
item x = super.removelast();
lostitem.addlast();
return x;
}
```
## boring constructor

Constructors are not inherited. However, the rules of Java say that all constructors must start with a call to one of the super class's constructors 
- ldea: if every VengefulSLList is-anSLList, every VengefulSLList must be setup like an SLList.
   - if you didn't call SLList constrlIctor, sentinel would be null. Very bad.  ↓
- You can explicitly call the constructor with the keyword super (no dot).
If you don't explicitly call the constructor, Java will automatically do it for you
```
public vengefulslist{
	super();
	deleteditems = new slist<item>();
}
```
==如果你重载了构造函数(子类父类同时)，那么就需要显示调用super( )并传入参数==


### object class
As it happens, every type in Java is a descendant of the Object class.
VengefulSLList extends SLList.SLList extends Object (implicitly)

#### 强调
implementation?
is-a!

Important: In both cases, we specify “is-a" relationships, not “has-a”Good: Dog implements Animal, SLList implements List61B.Bad: Cat implements Claw, Set implements SLList.

#### encapsulation
Module: A set of methods that work together as a whole to perform some task or set of related tasks.

A module is said to be encapsulated if its implementation is completely hidden and it can be accessed only through documented interface.

#### compile time type checking
Compiler allows method calls based on compile-time type of variable.

![[Pasted image 20250928212514.png]]
![[Pasted image 20250928212655.png]]

#### casting!
Java has a special syntax for specify the compile-time type of any expression.

Put desired type in parenthesis before the expression.
Examples:
	Compile-time type `Dog,maxDog(frank,frank]r);`
	Compile-time type Poodle:`(Poodle)maxDog(frank,frankJr);`

##### remember
Casting is a powerful but dangerous tool

Tells Java to treat an expression as having a different compile-time type.
In example below, effectively tells the compiler to ignore its type checking duties.
Does not actually change anything: sunglasses don't make the world dark.
```
Poodle frank = new Poodle("Frank",5);
Malamute frankSr = new Malamute("Frank Sr.",100);
Poodle largerPoodle =(Poodle)maxDog(frank,frankSr);
```

lf we run the code above, we get a ClassCastException at runtime.
```
//1 interface
public interface intunaryfunction{
	public int apply(int x);
	}
//2 method
public class tenx implements intunaryfunction {
		@override
		public int apply(int x){
			return 10 * x;
			}
}
//3 usage
public hofdemo{
	public static int dotwice(intunaryfunction f, int x){
	return f.apply(f.apply(x));
	}
	
	public static void main(String[] args){
		int res = dotwice(new tenx(),2);
		System.out.println(res);
	}
}
```

#### higher order functions in java

a function that treats another function as data

Old School (Java 7 and earlier)
Fundamental issue: Memory boxes (variables) cannot contain pointers tofunctions.
Can use an interface instead. Let's try it out.


In Java 8, new types were introduced: now can can hold references to methods.
You're welcome to use these features, but we won't teach them.
Why? The old way is still widely used, e.g. Comparators (see next lecture).
![[Pasted image 20250929220050.png]]

# lec10 sub-type polymorphism vs. Explicit Higher order function

![[Pasted image 20250929220637.png]]

### big goal: naive general MAX function

suppose we want to write a function max() that returns the max of any array,regardless of type

create an interface that guarantees a comparison method.
 - have dog implement this interface
 - write `maximizer` class in terms of this interface.
					`ourcomparable`   
						↑
						`dog`


Benefits of this approach:
No need for array maximization code in every custom type (i.e. noDog.maxDog(Dog[])function required).Code that operates on multiple types (mostly) gracefully, e.g.
#### compilation error puzzle (skip)

two issues:
- awkward casting to/from objects
- only dog has `OurComparable`  (strings don't!  NOT GENERAL)


The industrial strength approach: Use the built-in Comparable interface.
Already defined and used by tons of libraries.Uses generics.

```
public interface Comparable<T>{
	public int comapreTo(T obj);
}
```


					`Comparable<Dog>`   
						↑
						`dog`


### `Comparator`

natural order: the order use Comaprable's compareTo method.

if i need other order?
		 easy with higher order function


warpped function with class `comparator<X>` (not able)
```
public interface Comparator<T>{
	int compare(T o1,T o2);
}
```

```
class namecomparator implements comparator<T>;
```

使用嵌套类、static关键字

`dog.namecomparator nc = new dog.namecomparator;`

继续改动，权限隔离 声明为Private
然后写一个get方法

# lec11 iterators,object methods

### goal : build an implementation of set called `arrayset`

add some 'industrial strength' like iteration comparison and` tostirng`

#### iteration : enhanced for-loop
iterator,next,`hasNext`

To support ugly iteration:
Add an iterator() method to `ArraySet` that returns an Iterator<`T`>.The Iterator<`T`> that we return should have a useful `hasNext( )` and next()method.

```
private class arraysetiterator<T> implements Iterator<T>{
	boolean hasNext();
	T next();
}
```
still 'for each' don't work

res: java not knows we have iterator
solution:  guarantee java we have one
```
public class ArraySet<T> implements Iterable<T> {
}
```

for std iterable:
```
public interface Iterable<T>{
Iterator<T> iterator();
}
```

 #java面向对象 ==implements是class获得interface的关键字==
### object method
#### `tostring`
The `tostring()` method provides a string representation of an object.
exp `System.out.printIn(Object x)` calls `x.tostring()` 
If you're curious: `println` calls `String.valueOf` which calls `toString`


override tostring for ArraySet  (till now we use default Object's)


- something out of class: StringBuilder
		currently string is imutable, we just copy and add

for StrBuider: append() method

细节，遍历使用this，因为我们已经实现迭代器，所以可以跳过空值

### equals()
not `==`: `==` check the same one(memory address)
 not default

catch
```
@override
public boolean equals(Object o){
	↓
}
```
新关键字 `instanceof` 除了真假，如果为真，还会自动转换生成变量↓`otherset`接收

```
if( o instance of ArraySet otherset){
	if size不等
	for( T i : this){
		if(!otherset.contains[oi]){
		return false;
		}
	}
	return true;
}
return false;
```









