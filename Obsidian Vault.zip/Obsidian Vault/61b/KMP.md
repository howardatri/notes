计算next


```
void buildNext(char *P, int next[], int m){ 
	int k=next[0]=-1; 
	for(int j=0; j=0 && P[k]!=P[j]) k=next[k]; 
	//求p0…pk-1的最长相等前后缀 
	next[j+1]=++k; 
	} 
}
```

![[Pasted image 20251007155635.png]]


![[Pasted image 20251007155601.png]]
